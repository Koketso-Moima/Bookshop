/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bookshop.BookShop;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import za.ac.tut.comicnovel.ComicNovel;

/**
 *
 * @author Student
 */
public class BookShop {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String[] bookInfo = {"The Stupidest Angel#2#CM002",
                            "Vile Bodies#8#EW008",
                            "Cold Comfort Farm#1#SG001",
                            "Lightning Rods#2#HDW002",
                            "A Complicated Kindness#1#MT001",
                            "Auntie Mame#9#PD009",
                            "Catch-22#5#JH005",
                            "The Color of Magic#1#TP001",
                            "Lucky Jim#3#KA003"};
        
        ArrayList<ComicNovel> theBooks=new ArrayList<ComicNovel>();
        int volume=0;
        for(int i=0;i<bookInfo.length;i++)
        {
            String[] books=bookInfo[i].split("#");
            String title=books[0];
            
             volume=Integer.parseInt(books[1]);
            
            String code=books[2];
            
            ComicNovel sc=new ComicNovel(title, volume, code);
            theBooks.add(sc);
            
        }
        JOptionPane.showMessageDialog(null, theBooks.size());
    }
    
    public static String globalDetails(ArrayList<ComicNovel> paremeter)
    {
        String message= "The list of comic novels with its search code:";
        JOptionPane.showMessageDialog(null, "=============================================================");
         for(int x=0;x<paremeter.size();x++)
         {
             String temp="";
             ComicNovel sc=paremeter.get(x);
             temp="\n"+sc.getTitle()+"=>"+sc.getCode();
            // temp=paremeter.get(x).getTitle()+" => "+paremeter.get(x).getCode();
             message +=temp;
         }
          JOptionPane.showMessageDialog(null, message);
        return message;
    }
    
}
